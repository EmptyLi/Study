alter table ray_hist_bond_pledge rename to hist_bond_pledge;
commit;
alter table ray_hist_bond_warrantor rename to hist_bond_warrantor;
commit;
alter table ray_stg_bond_pledge rename to stg_bond_pledge;
commit;
alter table ray_stg_bond_warrantor rename to stg_bond_warrantor;
commit;
