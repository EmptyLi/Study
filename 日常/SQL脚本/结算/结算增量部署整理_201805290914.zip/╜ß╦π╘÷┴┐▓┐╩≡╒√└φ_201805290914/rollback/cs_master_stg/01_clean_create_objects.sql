drop table if exists hist_bond_pledge;
commit;
drop table if exists hist_bond_warrantor;
commit;
drop table if exists stg_bond_pledge;
commit;
drop table if exists stg_bond_warrantor;
commit;
