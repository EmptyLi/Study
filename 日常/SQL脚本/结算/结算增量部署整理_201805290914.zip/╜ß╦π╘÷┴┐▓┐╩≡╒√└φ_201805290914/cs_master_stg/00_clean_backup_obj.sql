drop table if exists ray_hist_bond_pledge;
commit;
drop table if exists ray_hist_bond_warrantor;
commit;
drop table if exists ray_stg_bond_pledge;
commit;
drop table if exists ray_stg_bond_warrantor;
commit;
