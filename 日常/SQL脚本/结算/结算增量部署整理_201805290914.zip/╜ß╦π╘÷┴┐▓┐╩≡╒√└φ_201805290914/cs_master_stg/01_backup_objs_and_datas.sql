alter table hist_bond_pledge rename to ray_hist_bond_pledge;
commit;
alter table hist_bond_warrantor rename to ray_hist_bond_warrantor;
commit;
alter table stg_bond_pledge rename to ray_stg_bond_pledge;
commit;
alter table stg_bond_warrantor rename to ray_stg_bond_warrantor;
commit;
