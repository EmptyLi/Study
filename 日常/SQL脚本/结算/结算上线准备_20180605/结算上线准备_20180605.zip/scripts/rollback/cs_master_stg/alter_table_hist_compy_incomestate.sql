drop table if exists hist_compy_incomestate;
alter table ray_hist_compy_incomestate rename to hist_compy_incomestate;
commit;