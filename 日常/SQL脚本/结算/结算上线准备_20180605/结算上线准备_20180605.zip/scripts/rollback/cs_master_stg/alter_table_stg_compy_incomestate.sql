drop table if exists stg_compy_incomestate;
alter table ray_stg_compy_incomestate rename to stg_compy_incomestate;
commit;