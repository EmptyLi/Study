drop table if exists hist_bond_warrantor;
alter table ray_hist_bond_warrantor rename to hist_bond_warrantor;
commit;