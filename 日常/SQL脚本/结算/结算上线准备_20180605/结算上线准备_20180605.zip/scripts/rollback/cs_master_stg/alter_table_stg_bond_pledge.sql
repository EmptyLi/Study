drop table if exists stg_bond_pledge;
alter table ray_stg_bond_pledge rename to stg_bond_pledge;
commit;