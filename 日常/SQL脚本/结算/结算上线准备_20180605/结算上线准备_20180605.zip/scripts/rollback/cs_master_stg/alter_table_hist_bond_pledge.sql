drop table if exists hist_bond_pledge;
alter table ray_hist_bond_pledge rename to hist_bond_pledge;
commit;