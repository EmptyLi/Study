drop table if exists stg_bond_warrantor;
alter table ray_stg_bond_warrantor rename to stg_bond_warrantor;
commit;