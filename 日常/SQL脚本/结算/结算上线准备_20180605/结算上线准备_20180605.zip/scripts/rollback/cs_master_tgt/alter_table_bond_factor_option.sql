alter table ray_bond_factor_option rename to bond_factor_option;
commit;