alter table ray_rating_factor rename to rating_factor;
commit;