alter index ray_pk_bond_rating_model rename to pk_bond_rating_model;
commit;