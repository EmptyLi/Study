-- 需要恢复数据
alter table ray_bond_rating_model rename to bond_rating_model;
commit;