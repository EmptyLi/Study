alter table ray_bond_rating_factor rename to bond_rating_factor;
commit;