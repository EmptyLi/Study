alter index ray_pk_bond_rating_record rename to pk_bond_rating_record;
commit;