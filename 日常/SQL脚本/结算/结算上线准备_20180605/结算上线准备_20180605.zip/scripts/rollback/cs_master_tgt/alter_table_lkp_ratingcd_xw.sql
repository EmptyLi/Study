alter table ray_lkp_ratingcd_xw rename to lkp_ratingcd_xw;
commit;