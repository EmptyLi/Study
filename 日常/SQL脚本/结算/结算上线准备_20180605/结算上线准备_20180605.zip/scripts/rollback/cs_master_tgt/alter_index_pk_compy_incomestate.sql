alter index ray_pk_compy_incomestate rename to pk_compy_incomestate;
commit;