alter table ray_bond_rating_record rename to bond_rating_record;
commit;