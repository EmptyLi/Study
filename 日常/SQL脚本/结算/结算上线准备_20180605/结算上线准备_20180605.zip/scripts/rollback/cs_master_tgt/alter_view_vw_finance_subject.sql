alter view ray_vw_finance_subject rename to vw_finance_subject;
commit;