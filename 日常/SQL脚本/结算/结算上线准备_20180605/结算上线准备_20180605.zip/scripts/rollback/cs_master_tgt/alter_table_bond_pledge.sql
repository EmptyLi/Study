alter table ray_bond_pledge rename to bond_pledge;
commit;