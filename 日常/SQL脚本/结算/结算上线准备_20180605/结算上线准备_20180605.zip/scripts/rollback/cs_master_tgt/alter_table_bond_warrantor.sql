alter table ray_bond_warrantor rename to bond_warrantor;
commit;