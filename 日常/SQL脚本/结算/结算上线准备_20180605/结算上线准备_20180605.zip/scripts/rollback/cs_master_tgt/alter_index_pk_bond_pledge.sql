alter index ray_pk_bond_pledge rename to pk_bond_pledge;
commit;