alter table ray_compy_incomestate rename to compy_incomestate;
commit;