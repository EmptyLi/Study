alter index ray_pk_bond_rating_factor rename to pk_bond_rating_factor;
commit;