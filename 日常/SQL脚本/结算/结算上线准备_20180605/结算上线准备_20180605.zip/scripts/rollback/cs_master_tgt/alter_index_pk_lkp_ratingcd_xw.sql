alter index ray_pk_lkp_ratingcd_xw rename to pk_lkp_ratingcd_xw;
commit;