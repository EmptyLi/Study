alter materialized view ray_vw_compy_finanalarm rename to vw_compy_finanalarm;
commit;