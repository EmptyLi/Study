update bond_rating_model
   set model_nm ='LGD专家模型';
commit;