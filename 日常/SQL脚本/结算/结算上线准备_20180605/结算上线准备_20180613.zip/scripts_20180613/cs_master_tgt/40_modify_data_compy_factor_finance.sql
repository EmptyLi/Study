update compy_factor_finance
   set isdel = 1
where factor_cd in ('factor_019','factor_021','factor_052','factor_005','factor_008');
commit;
