alter view ray_vw_bond_rating_cacul rename to vw_bond_rating_cacul;
commit;