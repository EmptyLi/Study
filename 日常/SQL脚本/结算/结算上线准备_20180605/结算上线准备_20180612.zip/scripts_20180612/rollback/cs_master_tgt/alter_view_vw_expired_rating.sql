alter view ray_vw_expired_rating rename to vw_expired_rating;
commit;