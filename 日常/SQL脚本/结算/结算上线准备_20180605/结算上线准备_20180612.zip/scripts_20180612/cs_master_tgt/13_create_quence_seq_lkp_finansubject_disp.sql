create sequence SEQ_LKP_FINANSUBJECT_DISP
minvalue 1
start with 1423
increment by 1
cache 20;
