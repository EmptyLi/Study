drop function if exists fn_compy_finance_check();
alter function ray_fn_compy_finance_check() rename to fn_compy_finance_check;
commit;